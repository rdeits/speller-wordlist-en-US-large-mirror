This zip file contains the words found in the corresponding Hunspell
dictionary.  See the file README_en_US-large.txt.
